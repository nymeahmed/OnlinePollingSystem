<!DOCTYPE html>
<html>
<head>
      <title> Admin Sign UP</title>
      <link rel="stylesheet" href="adminsign.css">
      
</head> 
<body>
    <!--container-->
    <div class="container">
    <form method="post" action="adminsign.php"> 
      
		<h1 class="neon"> Online Polling System </h1>
      <h2 class="neon1">Admin Signup Form</h2>
      <div class="textbox">
        <i class="fa fa-user-circle" aria-hidden="true"></i>
        <input type="text" placeholder="Name"  name="name" required>
      </div>
      <div class="textbox">
        <i class="fa fa-user-circle" aria-hidden="true"></i>
        <input type="text" placeholder="User Name"  name="username" required>
    </div>
        <div class="textbox">
            <i class="fa fa-phone" aria-hidden="true"></i>
            <input type="tel" placeholder="Phone Number"  name="phone" required >
          </div>
     
    
      <div class="textbox">
        <i class="	fa fa-envelope-o" aria-hidden="true"></i>
        <input type="email" placeholder="Email"  name="email" required >
      </div>
      <div class="textbox">
        <i class="fa fa-key fa-fw"></i>
        <input type="password"  placeholder="Password" name="password" required >      
      </div> 
      <div class="textbox">
        <i class="fa fa-key fa-fw"></i>
        <input type="password"  placeholder="Re-Type Password" name="cpassword" required >      
      </div> 
      <center>

           <?php
                $db = mysqli_connect("localhost", "root", "", "pollingsystem");
                if(isset($_POST['submit'])) {
                $name = $_POST['name'];
                $username = $_POST['username'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $cpassword = $_POST['cpassword'];
                if($password == $cpassword){
                        $sql = "INSERT INTO admin(name, username, number, email, password) VALUES('$name', '$username', '$phone', '$email', '$cpassword')";
                        mysqli_query($db, $sql); //data is inserted into the database
                        echo "<script>
                                  alert('Admin signup successful');
                              </script>";
                }else{
                        echo "Password doesn't match";
                }
                }
        ?>


        <a href="#" id="login">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <!--NEED CSS-->
          <input type="submit" name="submit" value="Submit"  style="background-color:#078D18;" >
          <!-- NEED CSS-->
        </a>
        <a href="#" id="cancel">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <!-- NEED CSS
          <b><input type="submit" name="back" value="Back" style="background-color: #e60000">-->
            <a href="index.php">Back </a>
           <!--<a href="loginpage.php">Back</a> -->
          <!-- this loginpage.php will be linked after marge -->
          <!-- NEED CSS-->
        </a>
      </center>
     <br>  
      </div>            
    </form>
 
      </div>
      <footer id="main-footer">
        <hr>
        <p><b>Copyright &copy; 2020 Nila Sultana </p>
      </footer>
  </body>
<html>
