<!DOCTYPE html>
<html>
<head>
      <title>Sign UP</title>
      <link rel="stylesheet" href="sign.css">
</head> 
<body>
      <!--container-->
      <div class="container">
      <form method="post" action="sign.php">
        <h1 class="neon"> Online Polling System </h1>
        <h2 class="neon1"> User Signup Form</h2>
        <div class="textbox">
          <i class="fa fa-user-circle-o" aria-hidden="true"></i>
          <input type="text" placeholder="First Name"  name="fname" required>
        </div>
        <div class="textbox">
          <i class="	fa fa-user-circle-o" aria-hidden="true"></i>
          <input type="text" placeholder="Last Name"  name="lname" required>
        </div>
        <div class="textbox">
          <i class="fa fa-user-circle-o" aria-hidden="true"></i>
          <input type="text" placeholder="User Name"  name="uname" required>
        </div>
      
        <div class="textbox">
          <i class="fa fa-envelope-square" aria-hidden="true"></i>
          <input type="email" placeholder="Email"  name="email" required >
        </div>
        <div class="textbox">
          <i class="fa fa-phone" aria-hidden="true"></i>
          <input type="tel" placeholder="Phone Number"  name="number" required >
        </div>
        <!-- gender adding, NEED CSS -->
        <div class="textbox1">
       <b> <i class="fa fa-venus-mars" aria-hidden="true"></i><b>
            <label for="gender">Gender</label>
            <input type="radio" name="gender" value="male" required>
            <label for="male">Male</label>
            <input type="radio" name="gender" value="female" required>
            <label for="female">Female</label>
            <input type="radio" name="gender" value="other" required>
            <label for="other">Other</label>
        </div> <br>
        <!-- gender adding, NEED CSS -->
        <div class="textbox">
          <i class="fa fa-child" aria-hidden="true"></i>
          <input type="tel" placeholder="Age"  name="age" required >
        </div>
        <div class="textbox">
          <i class="fa fa-home" aria-hidden="true"></i>
          <input type="area" placeholder="Present Address"  name="address" required>
        </div>
        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Password" name="password" required >      
        </div> 
        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Re-Type Password" name="cpassword" required>      
        </div> 
            
        <div>
          <br>
          <div class="center" >
            <input type="checkbox" name="Remember"><i id="rem"> I agree with all the terms & conditions.</i>     
          </div>

            <?php
                $db = mysqli_connect("localhost", "root", "", "pollingsystem");
                if(isset($_POST['submit'])) {
                  session_start();
                  $fname = $_POST['fname'];
                  $lname = $_POST['lname'];
                  $uname = $_POST['uname'];
                  $email = $_POST['email'];
                  $number = $_POST['number'];
                  $gender = $_POST['gender'];
                  $age = $_POST['age'];
                  $address = $_POST['address'];
                  $password = $_POST['password'];
                  $cpassword = $_POST['cpassword'];
                  $value = 18;
                  if($age >= $value){
                          if($password == $cpassword){
                              $sql = "INSERT INTO user(firstname, lastname, username, email, number, gender, age, address, password ) VALUES('$fname', '$lname', '$uname', '$email', '$number', '$gender', '$age', '$address', '$cpassword')";
                              mysqli_query($db, $sql); //data is inserted into the database
                              /*echo "<script>
                                  alert('User signup successful');
                                </script>";*/
                              $_SESSION['fname']=$fname;
                              $_SESSION['lname']=$lname;
                              $_SESSION['uname']=$uname;
                              $_SESSION['email']=$email;
                              $_SESSION['number']=$number;
                              $_SESSION['gender']=$gender;
                              $_SESSION['age']=$age;
                              $_SESSION['address']=$address;
                        //$_SESSION['password']=$password;
                              header("location: usersuccess.php");
                          }else{
                              echo "Password doesn't match";
                            }
                  }
                  else{
                    echo "Your age must be 18 or above for signup";
                  }
                }
        ?>

        <center>
          <a href="#" id="login">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <!--NEED CSS-->
          <b>  <input type="submit" name="submit" value="Submit"style="background-color:#078D18;" ><b>
            <!--NEED CSS-->
          </a>
          <a href="#" id="cancel">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <!-- NEED CSS
            <input type="submit" name="back" value="Back"style="background-color: #e60000">-->
            <a href="index.php">Back </a>
            <!--<a href="loginpage.php">Back</a> -->
            <!-- this loginpage.php will be linked after marge -->
            <!-- NEED CSS-->
          </a>
        </center>
       <br>  
        </div>            
      </form>
   
        </div>
        <footer id="main-footer">
          <hr>
          <p>Copyright &copy; 2020 Nila Sultana </p>
        </footer>
    </body>
<html>
