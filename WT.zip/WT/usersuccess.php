<!DOCTYPE html>
<html>
<head>
  <title>User Signup Successful</title>
  <link rel="stylesheet"  href="usersuccess.css">
      
      </head>
<body>
    <center>
   <div>
      <form method="post" action="usersuccess.php">
        <h2>Online Polling System</h2><br><br>
       

  <fieldset>
  <?php
    session_start();
    if(isset($_SESSION['fname']) && $_SESSION['lname'] && $_SESSION['uname'] && $_SESSION['gender']
       && $_SESSION['number'] && $_SESSION['address'] && $_SESSION['email'] && $_SESSION['age']) {
        echo "<b>Welcome ".$_SESSION['fname']." ".$_SESSION['lname']."</b><br>";
        echo "<b>You have been successfully registered in the system<b><br>";
        echo "<b>Your username is: ".$_SESSION['uname']."</b><br>";
        echo "<b>Your gender is: ".$_SESSION['gender']."</b><br>";
        echo "<b>Your age is: ".$_SESSION['age']."</b><br>";
        echo "<b>Your number is: ".$_SESSION['number']."</b><br>";
        echo "<b>Your address is: ".$_SESSION['address']."</b><br>";
        echo "<b>Your email is: ".$_SESSION['email']."</b><br><br>";
        echo "Please logout and log back in.<br><br><br>";
        echo "<a href='index.php'>Go to the home page</a>";
    }
?>
       
   </form>
  </fieldset>
  </div>
   
</center>
<footer id="main-footer">
          <hr>
          <p><b>Copyright &copy; 2020 Nila Sultana </p>
        </footer>
</body>

</html>
