<!-- NEED CSS -->
<!DOCTYPE html>
<html>
<head>
	<title>Permission for Admin Signup</title>
	<link rel="stylesheet" href="per.css">
</head>
<body>
	<center>
	<fieldset>
	<legend><h1>Need Permission For Admin Signup </h1></legend>
	<form method="post" action="permission.php">
		<p><b>Please Provide the Refrence Code for Admin Signup</b></p>
		<input type="text" name="permission"> <br> <br>
		<!--<input class="neon" type="submit" name="cancel" value="Go Back">-->
		<a href="index.php">Go back</a>
		<input class="neon1" type="submit" name="submit" value="Check">
	</form>
	</fieldset>
	<?php 
	if (isset($_POST['submit'])) {
		$check = $_POST['permission'];
		if ($check ==12345  ){ //token=12345
			header("location: adminsign.php");
		}
		else {
			echo "Permission code doesn't match <br>";
		}
	}
	?>
</center>
<footer id="main-footer">
          <hr>
          <p><b>Copyright &copy; 2020 Nila Sultana </p>
        </footer>
</body>
</html>